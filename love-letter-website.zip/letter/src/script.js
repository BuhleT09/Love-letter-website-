_JavaScript(script.js)_

// Add animations

document.addEventListener('DOMContentLoaded', () => {

  const letterText = document.getElementById('letter-text');

  const heart = document.querySelector('.heart');
 // Add animations

document.addEventListener('DOMContentLoaded', () => {

  const letterText = document.getElementById('letter-text');

  const heart = document.querySelector('.heart');

  const revealButton = document.querySelector('.reveal-message button');

  const hiddenMessage = document.getElementById('hidden-message');

  if (letterText && heart && revealButton && hiddenMessage) {

    letterText.addEventListener('mouseover', () => {

      heart.style.transform = 'scale(1.2)';

    });

    letterText.addEventListener('mouseout', () => {

      heart.style.transform = 'scale(1)';

    });

    revealButton.addEventListener('click', () => {

      hiddenMessage.style.display = 'block';

      revealButton.style.display = 'none';

    });

  } else {

    console.error('One or more elements not found.');

  }

});

``` 